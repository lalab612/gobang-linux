#ifndef _QUEUE_H_
#define _QUEUE_H_

#define QUEUE_CAPACITY  50



typedef struct 
{
	unsigned char type;
	unsigned char leng[4];
	unsigned char subtype;
	unsigned char retain[4];
	unsigned char values[1014];
}msg_t;

typedef struct 
{
	char    enable;
	msg_t   msg;
	char    ip[16];
	int     port;     // 客户端端口
    int    	confd;
	
}bmsg_t;


typedef struct 
{
	char ip[16];
	int port;     // 客户端端口
}usermsg_t;

typedef struct 
{
    msg_t  		msg;
	usermsg_t   usermsg;
	char        type;
	char        subtype;
    int    		confd;
	char        step;
}queuemsg_t;
// 元素类型
typedef queuemsg_t elem_t;

// 队列类型
typedef struct 
{
	int capacity;    // 容量
	int len;         // 队长
	int front;       // 队头指针，非空时指向有效数据
	int rear;        // 队尾指针，非空时指向空位置
	elem_t data[QUEUE_CAPACITY];   // 队列数据
} queue_t;

/**
 * 功能：  初始化队列
 * 参数：  pq 队列指针
 * 返回值：无
 **/
void init_queue(queue_t *pq);

/**
 * 功能：  将 pe 元素入队到 pq 中
 * 参数：  pq 队列指针
 *         pe 元素数据指针
 * 返回值：成功返回 0，失败返回 -1
 **/
int enqueue(queue_t *pq, elem_t *pe);

/**
 * 功能：  从队列 pq 中出队，数据保存到 pe 中
 * 参数：  pq 队列指针
 *         pe 保存元素数据的缓冲区
 * 返回值：成功返回 0，失败返回 -1
 **/
int dequeue(queue_t *pq, elem_t *pe);

/**
 * 功能：  判断队列 pq 是否为空
 * 参数：  pq 队列指针
 * 返回值：队空返回 1，队非空返回 0
 **/
int is_empty(queue_t *pq);

/**
 * 功能：  判断队列 pq 是否已满
 * 参数：  pq 队列指针
 * 返回值：队满返回 1，不满返回 0
 **/
int is_full(queue_t *pq);

/**
 * 功能：  求队列 pq 的长度
 * 参数：  pq 队列指针
 * 返回值：队列长度
 **/
int get_length(queue_t *pq);

/**
 * 功能：  获取队列 pq 的 index 下标处的元素，通过 pe 返回
 * 参数：  pq    队列指针
 *         index 元素下标
 *         pe    返回元素数据的缓冲区
 * 返回值：成功返回 0，失败返回 -1
 **/
int get(queue_t *pq, int index, elem_t *pe);

/**
 * 功能：  遍历队列 pq
 * 参数：  pq 队列指针
 * 返回值：无
 **/
//void print_queue(queue_t *pq);

/**
 * 功能：  清空队列 pq
 * 参数：  pq 队列指针
 * 返回值：无
 **/
void clear_queue(queue_t *pq);

#endif

