
#include <stdio.h>
#include <string.h>
#include "queue_t.h"

/**
 * 功能：  初始化队列
 * 参数：  pq 队列指针
 * 返回值：无
 **/
void init_queue(queue_t *pq)
{
	pq->capacity = QUEUE_CAPACITY;
	pq->len = 0;
	pq->front = pq->rear = 0;  // front == rear 表示空队
}

/**
 * 功能：  将 pe 元素入队到 pq 中
 * 参数：  pq 队列指针
 *         pe 元素数据指针
 * 返回值：成功返回 0，失败返回 -1
 **/
int enqueue(queue_t *pq, elem_t *pe)
{
	// 队满则入队失败
	if (is_full(pq))
	{
		return -1;
	}

	// 队尾入队，rear 指针指向空位置，
	// 先存放数据，再调整 rear 指针
	memcpy(pq->data + pq->rear, pe, sizeof (elem_t));
	pq->rear = (pq->rear + 1) % pq->capacity;
	// 队长自增
	pq->len++;

	return 0;
}

/**
 * 功能：  从队列 pq 中出队，数据保存到 pe 中
 * 参数：  pq 队列指针
 *         pe 保存元素数据的缓冲区
 * 返回值：成功返回 0，失败返回 -1
 **/
int dequeue(queue_t *pq, elem_t *pe)
{
	// 队空则出队失败
	if (is_empty(pq))
	{
		return -1;
	}

	// 从队头出队，front 指针指向队列的有效数据，
	// 先取 front 处的数据，再调整 front 指针
	memcpy(pe, pq->data + pq->front, sizeof (elem_t));
	pq->front = (pq->front + 1) % pq->capacity;

	// 队长递减
	pq->len--;

	return 0;
}

/**
 * 功能：  判断队列 pq 是否为空
 * 参数：  pq 队列指针
 * 返回值：队空返回 1，队非空返回 0
 **/
int is_empty(queue_t *pq)
{
	//return pq->len == 0;
	return pq->front == pq->rear;
}

/**
 * 功能：  判断队列 pq 是否已满
 * 参数：  pq 队列指针
 * 返回值：队满返回 1，不满返回 0
 **/
int is_full(queue_t *pq)
{
	//return pq->len == pq->capacity - 1;
	return (pq->rear + 1) % pq->capacity == pq->front;
}

/**
 * 功能：  求队列 pq 的长度
 * 参数：  pq 队列指针
 * 返回值：队列长度
 **/
int get_length(queue_t *pq)
{
	//return pq->len;
	return (pq->rear + pq->capacity - pq->front) % pq->capacity;
}

/**
 * 功能：  获取队列 pq 的 index 下标处的元素，通过 pe 返回
 * 参数：  pq    队列指针
 *         index 元素下标
 *         pe    返回元素数据的缓冲区
 * 返回值：成功返回 0，失败返回 -1
 **/
int get(queue_t *pq, int index, elem_t *pe)
{
	// 作业
}

/**
 * 功能：  遍历队列 pq
 * 参数：  pq 队列指针
 * 返回值：无
 **/
/*void print_queue(queue_t *pq)
{
	int i;

	// 从 front 打印到 rear
	for (i = pq->front; i != pq->rear; 
				i = (i + 1) % pq->capacity)
	{
		fprintf(stderr, "%d  ", pq->data[i]);
	}
}
*/
/**
 * 功能：  清空队列 pq
 * 参数：  pq 队列指针
 * 返回值：无
 **/
void clear_queue(queue_t *pq)
{
	pq->len = 0;
	pq->front = pq->rear = 0;
}


