#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>

#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>

#include <pthread.h>

#include <sys/select.h>
#include <errno.h>
#include <sys/ioctl.h>
#include "queue_t.h"
#include "deal_t.h"
#include "uinsock.h"

#define BROADip  "192.168.0.255"
#define SERVport   6000

void *handle_server_read(void *arg);

void *handle_server_write(void *arg);

void *handle_server_send(void *arg);

// 库存数
volatile int amount = 0;

// 库存数
volatile int g_step = 0;

queue_t queue;

queuemsg_t   queuemsg;
// 互斥锁
pthread_mutex_t mutex = PTHREAD_MUTEX_INITIALIZER;

// 条件变量
pthread_cond_t cond = PTHREAD_COND_INITIALIZER;

int main(int argc, char **argv)
{
	in_port_t port;
	char *ip;
	int sockfd,sockfd1;
	struct sockaddr_in svr_addr, clt_addr;
	in_addr_t inaddr;
	socklen_t socklen = sizeof svr_addr;
	int broadcast=1;   // 非 0 表示设置广播，0 表示取消广播

	pthread_t pthread1 , pthread2 , pthread3;
	msg_t company;
	
 	// 初始化队列
	init_queue(&queue);	

    //	printf("%s",wbuf);
    /*if (argc != 3)
    {
        printf ("用法：%s <广播地址> <端口号>\n",argv[0]);
        return -1;
    }
    ip1 = argv[1];
    port1 = atoi(argv[2]);*/
    // 创建 UDP 套接字
	sockfd1 = socket(AF_INET /*PF_INET*/, SOCK_DGRAM, 0);
	if (-1 == sockfd1)
	{
		perror("failed to create sockfd!");
		return -1;
	}

	// 设置广播选项
	if (-1 == setsockopt(sockfd1, SOL_SOCKET, SO_BROADCAST, 
					&broadcast, sizeof(int)))
	{
		perror("failed to set broatcast options!\n");
		
	}

	// 配置接收者地址
	inaddr = inet_addr(BROADip);
	if (INADDR_NONE == inaddr)
	{
		printf("%s is false IP\n", BROADip);
		
	}
	svr_addr.sin_family = AF_INET;
	svr_addr.sin_port = htons(SERVport);
	svr_addr.sin_addr.s_addr = inaddr;
	company.type = 6;
    company.subtype = 0;
    memset(company.values, 0, sizeof company.values);
    
	// 广播发送
	if (-1 == sendto(sockfd1, &company, 1024, 0, 
					(struct sockaddr *) &svr_addr, socklen))
	{
		perror("send error!");
		
	}
	printf("send success!\n");

	// 广播接收服务器的IP
	if (-1 == recvfrom(sockfd1, &company, 1024, 0, 
					(struct sockaddr *) &clt_addr, &socklen))
	{
		perror("receive error!\n");
	
	}
	printf("receving %s(%d) send message：%d\t%d\n", 
				inet_ntoa(clt_addr.sin_addr), 
				ntohs(clt_addr.sin_port), company.type,company.subtype);

    if (company.type == 6 && company.subtype == 0)
    {
        printf ("receive server IP success!\n");
        close(sockfd1);
    }
    else 
    {
        printf ("server close!\n");
        close(sockfd1);
    }

    //tcp连接
    ip = inet_ntoa(clt_addr.sin_addr);
    port = ntohs(clt_addr.sin_port);
	// 创建套接字，并连接服务器
	if (-1 == (sockfd = uin_connect(ip, port)))
	{
		printf("uin_connect() error\n");
		return -1;
	}
	// 动态初始化互斥锁
	//pthread_mutex_init(&mutex, NULL);
	
	while (1)
	{
		if (pthread_create(&pthread1, NULL, handle_server_read, (void *)sockfd))
		{
			printf("failed to creat pthread read!\n");
			continue;
		}
		if (pthread_create(&pthread2, NULL, handle_server_write, (void *)sockfd))
		{
			printf("failed to creat pthread write!\n");
			pthread_detach(pthread1);   //如果线程2创建不成功，则关闭线程1
			continue;
		}
		
		if (pthread_create(&pthread3, NULL, handle_server_send, (void *)sockfd))
		{
			printf("failef to creat pthread write!\n");
			pthread_detach(pthread1);   //如果线程2创建不成功，则关闭线程1
			pthread_detach(pthread2);   //如果线程2创建不成功，则关闭线程1
			continue;
		}
		
		// 分离子线程
		pthread_detach(pthread1);
		pthread_detach(pthread2);
		pthread_detach(pthread3);
		
	    show_main_surface();
		g_step  = 0 ;  //证明在主界面
		
		pause();
	}

_out:
	close(sockfd);

	return 0;
}

void *handle_server_send(void *arg)
{
	int connfd = (int) arg;
	int nfds = connfd + 1;	
	int sendconfd ;
	int cnt;
	char wbuf[1024];
	bmsg_t bmsg;
	while(1)
	{
		
		//加锁
		pthread_mutex_lock(&mutex);	
		
		amount = get_length(&queue);	
		while (1 > amount)
		{
			pthread_cond_wait(&cond, &mutex);
		}	
		
		dequeue(&queue, &queuemsg);  //出队
		
        //外理数据
		bmsg = deal_data(queuemsg);
		
		if(bmsg.enable)
		{
			sendconfd  = connfd;			

			if (-1 == (cnt = n_send(sendconfd, (char *)&bmsg.msg, 1024)))
			{
				printf("send error!\n");
				//break;
			}
			else if (0 == cnt)
			{
				printf("server cloose!\n");
				//break;
			}
            else
			{
				printf("send \n");
				//printf("%d\n",bmsg.msg.type);
				//printf("%d\n",bmsg.msg.subtype);
			}				
		}		// 解锁
		
		pthread_mutex_unlock(&mutex);	
		
		pthread_yield();
	}	
	
}

void *handle_server_read(void *arg)
{
	int connfd = (int) arg;
	fd_set rset;
	
	int nfds = connfd + 1;	
	
	while (1)
	{
		char rbuf[1024] = "";
		int cnt;
		// 清空描述符集
		FD_ZERO(&rset);
		// 加入描述符到描述符集
		FD_SET(connfd, &rset);		
		// 收

		//监听接口是否有数据
		while ((-1 == select(nfds, &rset, NULL, NULL, NULL))
					&& errno == EINTR);	
		printf("receive \n");	
		//加锁
		pthread_mutex_lock(&mutex);				
		//加锁		
		if (FD_ISSET(connfd, &rset))   // 可读了
		{
			// 收
			if (-1 == (cnt = r_recv(connfd, rbuf, 1024)))
			{
				printf("receive error!\n");
				break;
			}
			else if (0 == cnt)
			{
				printf("server close!\n");
				break;
			}
			memcpy(&queuemsg.msg , rbuf , 1024);
			queuemsg.type = 1;
		    enqueue(&queue, &queuemsg);  //入队
		    amount++;		
		}		
	    // 解锁
		pthread_mutex_unlock(&mutex);
		
		// 通知等待条件的其它线程
		pthread_cond_broadcast(&cond);
	}

_out:
	printf("pthread number: %ld over!\n", pthread_self());
	close(connfd);

	return NULL;
}

void *handle_server_write(void *arg)
{
	int connfd = (int) arg;
	fd_set rset;
	msg_t msg;
	int nfds = STDIN_FILENO + 1;	
	char wbuf[1024]="";
	
	while (1)
	{
		int cnt;
		
		// 清空描述符集
		FD_ZERO(&rset);
		// 加入描述符到描述符集
		FD_SET(STDIN_FILENO, &rset);		

		//监听接口是否有数据
		while ((-1 == select(nfds, &rset, NULL, NULL, NULL))
					&& errno == EINTR);	
			printf("write \n");	
	    //加锁
	    pthread_mutex_lock(&mutex);				
		if (FD_ISSET(STDIN_FILENO, &rset))   // 可读了
		{		
			memset(wbuf , 0 , 1024);
			fgets(wbuf,1024,stdin);
			
			int i;
			for(i = 0 ; i <1024 ;i++)
		    {
				if(10==wbuf[i])wbuf[i]=0;
			}
			// 收
			queuemsg.type = 2;
			memcpy(queuemsg.msg.values , wbuf , 1024);
		    enqueue(&queue, &queuemsg);  //入队
		    amount++;			
		}
		// 解锁
		pthread_mutex_unlock(&mutex);
		// 通知等待条件的其它线程
		pthread_cond_broadcast(&cond);	
	}

_out:
	printf("pthread number :%ld over!\n", pthread_self());
	close(connfd);

	return NULL;
}
