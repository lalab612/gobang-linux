#ifndef _DEAL_H_
#define _DEAL_H_


#include "queue_t.h"

extern bmsg_t deal_data(queuemsg_t queuemsg );
extern void show_main_surface();
#endif