#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include "deal_t.h"
#include "queue_t.h"

extern volatile int g_step;

const char pmsg[][100]=
{
"--------------------------------------------------",
"~*         register      pls input : 1" ,
"~*         login         pls input : 2" ,
"~*         find friend   pls input : 3" ,
"~*         add friend    pls input : 4" ,
"~*         chat          pls input : 5" ,
"~*         creat group   pls input : 7" ,

"--------------------------------------------------"
};

void show_main_surface()
{
	int i;
	for(i = 0 ;i < 7 ;i++)
	{
		printf("%s\n" ,pmsg[i]);
	}	
	
}

char groname[11];
char frenid[9];

typedef struct 
{
	char name[10];
	char password[6];
	char id[8];
	char txt[1006];
}registermsg_t; 
 
registermsg_t  registermsg;
 
bmsg_t deal_recive_data(queuemsg_t queuemsg);
bmsg_t deal_write_data(queuemsg_t queuemsg);

void pre_deal_write_data(queuemsg_t *queuemsg );

bmsg_t  deal_rev_register(queuemsg_t queuemsg);
bmsg_t  deal_rev_login(queuemsg_t queuemsg);
bmsg_t  deal_rev_find(queuemsg_t queuemsg );
bmsg_t  deal_rev_add(queuemsg_t queuemsg );
bmsg_t  deal_rev_state(queuemsg_t queuemsg );
bmsg_t  deal_rev_chat(queuemsg_t queuemsg );
bmsg_t  deal_rev_creatgro(queuemsg_t queuemsg );

bmsg_t  deal_register(queuemsg_t queuemsg);
bmsg_t  deal_login(queuemsg_t queuemsg);
bmsg_t  deal_find(queuemsg_t queuemsg );
bmsg_t  deal_add(queuemsg_t queuemsg );
bmsg_t  deal_state(queuemsg_t queuemsg );
bmsg_t  deal_chat(queuemsg_t queuemsg );
bmsg_t  deal_creatgro(queuemsg_t queuemsg );

bmsg_t deal_data(queuemsg_t queuemsg )
{
	bmsg_t  bmsg;
	
	switch(queuemsg.type)
	{
		case 1: 		
		    bmsg =  deal_recive_data(queuemsg);
		break;
		  
		case 2:
            bmsg =  deal_write_data(queuemsg);
        break;		
		
		default:
		break;
	}
	return bmsg;
}

bmsg_t deal_recive_data(queuemsg_t queuemsg )//处理接收到的数据
{
    bmsg_t bmsg;
	
	switch(queuemsg.msg.type)
	{	
		//注册
		case 0:
			bmsg = deal_rev_register(queuemsg );
		break;
		//登录
		case 1:
	        bmsg = deal_rev_login(queuemsg );
		break;
		
		//查找
		case 2:       
	        printf("-------------------- find friend ------------------\n");
	        bmsg = deal_rev_find(queuemsg );
		break;
		
		//添加
		case 3:
	        printf("-------------------- add friend -------------------\n");
	        bmsg = deal_rev_add(queuemsg );
		break;	
		
		//客户状态
		case 4:
		      bmsg = deal_rev_state(queuemsg );
		break;

		case 5:
			printf("--------------------- chating --------------------\n");
	    	bmsg = deal_rev_chat(queuemsg );
		break;
		
		//广播
		case 6:
		break;	

		case 7:
		    printf("------------------- group chating ----------------\n");
		    bmsg = deal_rev_creatgro(queuemsg );
		break;		
		
		default:
		    printf("—————————————————— receive error ——————————————————\n");
		break;	
		
	}	
	return bmsg;
}

bmsg_t  deal_rev_register(queuemsg_t queuemsg)//注册
{
	bmsg_t bmsg;
	
	switch(queuemsg.msg.subtype)
	{
		case 0:
		{
			char id[10] = "";
			memcpy(id , queuemsg.msg.values , 8);
			memcpy(registermsg.id , queuemsg.msg.values , 8);
			bmsg.enable = 0;
			printf("id = %s \n",id);
			
			g_step = 1;
			printf("please input name:");	
            fflush(stdout);			
		}
		break;
		
		case 1:
		{
		    g_step = 0;  //返回主界面
		    printf("  ~*register success!!!\n");
			show_main_surface();
			bmsg.enable = 0; //设置不发送
		}
		break;
		
		default:
		break;
	}	
	return bmsg;	
}

bmsg_t  deal_rev_login(queuemsg_t queuemsg)//登录
{
	char id[10]="", name[12]="" ,exist[3];
	bmsg_t bmsg;
	if(queuemsg.msg.subtype ==0 )
	{
	   g_step = 0;  //返回主界面
	   printf("  ~*login fail!!!\n");
	   show_main_surface();
	   bmsg.enable = 0; //设置不发送			
	}
	else
	{
	   printf("  ~*login success!!!\n");

	   int i;
	   printf("     %-17s %-17s %-17s\n" ,   "id","name","exist");
	   printf("--------------------------------------------------\n");
	   for(i = 0 ; i < queuemsg.msg.retain[3] ; i++)
	   {
           
		   memset(id , 0 ,10);
		   memset(name , 0 ,12);
		   memset(exist , 0 ,3);
		   memcpy( id ,queuemsg.msg.values+i*19 ,8 );
		   memcpy( name ,queuemsg.msg.values+8+i*19 ,10 );
		   memcpy( exist,queuemsg.msg.values+18+i*19 ,1 );
		   printf("%-13s          %-13s          %-13s\n" ,id ,name ,exist); 
	   }

	   bmsg.enable = 0; //设置不发送	
       g_step = 0;  //返回主界面
	}	   	
	return bmsg;	
}

bmsg_t  deal_rev_find(queuemsg_t queuemsg )//查找
{
	bmsg_t bmsg;
	char id[10]="", name[12]="" ,exist[3];
	if(queuemsg.msg.subtype ==0 )
	{
	   g_step = 0;  //返回主界面
	   printf("find friend fail!!!\n");
	   show_main_surface();
	   bmsg.enable = 0; //设置不发送			
		
	}
	else
	{
	   printf("find friend success!!!\n");
	   int i;
	   printf("     %-17s %-17s %-17s\n" ,   "id","name","exist");
	   printf("--------------------------------------------------\n");
	   for(i = 0 ; i < queuemsg.msg.retain[3] ; i++)
	   {
           
		   memset(id , 0 ,10);
		   memset(name , 0 ,12);
		   memset(exist , 0 ,3);
		   memcpy( id ,queuemsg.msg.values+i*19 ,8 );
		   memcpy( name ,queuemsg.msg.values+8+i*19 ,10 );
		   memcpy( exist,queuemsg.msg.values+18+i*19 ,1 );
		   printf("%-13s          %-13s          %-13s\n" ,id ,name ,exist); 
	   }
	  
	   bmsg.enable = 0; //设置不发送	
       g_step = 0;  //返回主界面
	}
	
	return bmsg;	
}

bmsg_t  deal_rev_add(queuemsg_t queuemsg )//添加
{
    bmsg_t bmsg;
	
	char id[10]="", name[12]="" ;	

	switch (queuemsg.msg.subtype)
	{
		case 0:
		    printf("************* b is agree! ************\n");			
		break;

		case 1:
	        printf("————————————— b no agree! ————————————\n"); 
		break;

		case 2:
	        printf("————————————— b no exist! ————————————\n");   
		break;
		
		case 3:
	        printf("-------------------Message-------------------\n");
		    memset(id , 0 ,10);
		    memset(name , 0 ,12);
		    memcpy( id ,queuemsg.msg.values ,8 );
		    memcpy( name ,queuemsg.msg.values+8 ,10 );
		    printf("%-13s          %-13s\n" ,id ,name); 
            printf("-------------------Message-------------------\n");
            printf("agree pls input :1 ---disagree pls input : 2\n");
            g_step = 6;	      		   
		break;

		default:
		break;
	}
	
	
	return bmsg;	
}

bmsg_t  deal_rev_state(queuemsg_t queuemsg )
{
    bmsg_t bmsg;

	
	return bmsg;	
}

bmsg_t  deal_rev_chat(queuemsg_t queuemsg )
{
    bmsg_t bmsg;
    char id[9]="", name[11]="" ,txt[1007]="";
	printf("-------------------Message-------------------\n");
    memset(id , 0 ,8);
    memset(name , 0 ,10);
    memset(txt , 0 ,1006);
    memcpy( id ,queuemsg.msg.values ,8 );
    memcpy( name ,queuemsg.msg.values+8 ,10 );
    memcpy( txt ,queuemsg.msg.values+8+10 ,1006);
    printf("%s-%s:%s\n" ,id ,name,txt); 
    printf("-------------------Message-------------------\n");
	printf("please input msg（please enter quit）:\n");
	memset(frenid , 0 ,9);
	memset(registermsg.txt , 0 ,1006);

	memcpy( frenid ,queuemsg.msg.values ,8 );
    g_step = 8;  //聊天
	bmsg.enable=0;
	return bmsg;	
}

bmsg_t deal_rev_creatgro(queuemsg_t queuemsg )
{
	bmsg_t bmsg;
	
	if(queuemsg.msg.subtype==0)
	{
		printf("*************creat group success!*************\n");
		g_step=0; 
	}
	else if(queuemsg.msg.subtype==1)
	{
		printf("***************creat group fail!**************\n");
		g_step=0; 
	}
	else if(queuemsg.msg.subtype==2)
	{
		printf("**************into group success!*************\n");
		g_step=0; 
	}	
	else if(queuemsg.msg.subtype==3)
	{
		printf("***********refuse into group fail!************\n");
		g_step=0; 
	}
	else if(queuemsg.msg.subtype==4)
	{
		printf("**************into group fail!***************\n");
		g_step=0; 
	}	
	else if(queuemsg.msg.subtype==5)
	{
		printf("*************seek group success!*************\n");
		char id[9]="", name[11]="",exist[2]="";
		int i;
		for(i = 0 ; i < queuemsg.msg.retain[3] ; i++)
		{
			printf("-----------------group member----------------\n");
		    memset(id , 0 ,9);
		    memset(name , 0 ,11);
		    memset(exist , 0 ,2);
		    memcpy( id ,queuemsg.msg.values+i*19 ,8 );
		    memcpy( name ,queuemsg.msg.values+8+i*19 ,10 );
		    memcpy( exist ,queuemsg.msg.values+8+10+i*19 ,1 );
		    printf("%-13s          %-13s          %-13s\n" ,id ,name ,exist); 
		    printf("-------------------Message-------------------\n");
		}
		g_step=0; //群选择界面
	}
	else if(queuemsg.msg.subtype==6)
	{
		printf("**************seek group fail!***************\n");
		g_step=0; 
	}			
	else if(queuemsg.msg.subtype==7)
	{
		//printf("****************send sucees!*****************\n");
		char  name[11]="" ,txt[1006]="";
		printf("-------------------Message-------------------\n");
	    memset(name , 0 ,10);
	    memset(txt , 0 ,1006);
	    memcpy( name ,queuemsg.msg.values,10 );
	    memcpy( txt ,queuemsg.msg.values+10 ,1006);
	    printf("%s:%s\n",name,txt); 
	    //printf("-------------------Message-------------------\n");
	    memset(groname , 0 ,11);
	    memcpy( groname ,queuemsg.msg.values,10 );
        g_step = 14;    
        printf("please input text（please enter quit）:\n");
	    fflush(stdout); 
		//g_step=13; //聊天界面
	}
	else if(queuemsg.msg.subtype==8)
	{
		printf("send fail");
		g_step=0;
	}	

	return bmsg;
}


bmsg_t deal_write_data(queuemsg_t queuemsg )
{
    bmsg_t bmsg;
	pre_deal_write_data(&queuemsg);
	switch(queuemsg.subtype)
	{	
		//注册
		case 0:
	        if(queuemsg.step == 1)
	        printf("-------------------register------------------\n");
			bmsg = deal_register(queuemsg );
		break;
		//登录
		case 1:
	        if(queuemsg.step == 1)
	        printf("--------------------login--------------------\n");
	        bmsg = deal_login(queuemsg );
		break;
		//查找
		case 2:
	        printf("------------------find friend----------------\n");
	        bmsg = deal_find(queuemsg );
		break;
		//添加
		case 3:
	        printf("------------------add friend-----------------\n");
	        bmsg = deal_add(queuemsg );
		break;		
		//1对1聊
		case 4:
			printf("-------------------chating-------------------\n");
	        bmsg = deal_chat(queuemsg );
		break;		
		//群
		case 6:
		    printf("--------------- group chating ---------------\n");
		    bmsg = deal_creatgro(queuemsg );
		break;

        case 120:
	        bmsg.enable = 0;  //设置不发送
			    
        break;		
		
		default:
	        bmsg.enable = 0; 
	        printf("————————————————— send error —————————————————\n");
		break;	
		
	}
	
	return bmsg;
}



void pre_deal_write_data(queuemsg_t *queuemsg )//发送信息
{
	switch(g_step)
	{
		case 0:   //主界面
			show_main_surface();
	        queuemsg->subtype = atoi(queuemsg->msg.values)-1;
		    queuemsg->step = 1;
		break;
		      
		case 1:  //输入昵称
	        memcpy(registermsg.name , queuemsg->msg.values , 10); 
		    queuemsg->subtype = 120;  //不发送
		    g_step = 2;
		    printf("please input password:");
		    fflush(stdout);	
	    break;
			  
		case 2:  //输入密码
            memcpy(registermsg.password , queuemsg->msg.values , 6); 
		    queuemsg->step = 2;  //到第二步
		    queuemsg->subtype = 0; //
            g_step = 0;//主界面
              
		break;
		
		case 3:  //登录输入ID以及下一步
		
	        memcpy(registermsg.id , queuemsg->msg.values , 8); 
		    queuemsg->subtype = 120;  //不发送
		    g_step = 4;   //到第四步
		    printf("please input password:");
		    fflush(stdout);	
	    break;	

		case 4:  //登录输入密码
            memcpy(registermsg.password , queuemsg->msg.values , 6);
		    queuemsg->subtype = 1; //
		    queuemsg->step = 2;  //到第二步
            g_step = 0;//主界面              
		break;	

		case 5:  //单独输入ID
            memcpy(registermsg.id , queuemsg->msg.values , 8);
		    queuemsg->subtype = 3; //
		    queuemsg->step = 2;  //请求添加
            g_step = 0;//主界面        
		break;	
		
		case 6:  //判断是否添加好友
		    queuemsg->subtype = 3; //
		    queuemsg->step = 3;  //是否同意添加好友
            g_step = 0;//主界面        
		break;

		case 7:  //单独输入ID
            memcpy(registermsg.id , queuemsg->msg.values , 8);
		    queuemsg->subtype = 3; //
		    queuemsg->step = 4;  //请求添加
            g_step = 0;//主界面            
		break;

		case 8:  //单独输入ID聊天
			memcpy(registermsg.txt , queuemsg->msg.values , 1006); 
			queuemsg->subtype = 4;
		    queuemsg->step = 2; 
           
		break;

		case 9:  //单独输入ID聊天      
            memcpy(frenid, queuemsg->msg.values , 8);
            queuemsg->subtype = 120;  //不发送
            printf("please input msg（please enter quit）:\n");
		    g_step = 8;  //聊天界面
		    
		break;		

		case 11://创建  
			//memcpy(registermsg.name , queuemsg->msg.values , 10); 
		    queuemsg->subtype = 6;  
		    queuemsg->step = 2;
		    //fflush(stdout);	
		    g_step = 12;//主界面
		break;

		case 12: //群选择
		    queuemsg->subtype = 6; 
		    queuemsg->step = 3; 
		break;

		case 13:  //转到聊天 
		    queuemsg->subtype = 120;  //不发送
            g_step = 14;    
            printf("please input text（please enter quit）:\n");
		    fflush(stdout);  
		break;	

		case 14:  //聊天
		    memcpy(registermsg.txt , queuemsg->msg.values , 1006); 
		    //printf ("%ld\n",strlen(registermsg.txt));
		    queuemsg->subtype = 6; //
		    queuemsg->step = 4; 
		break;			
	}	
	
}

bmsg_t deal_register(queuemsg_t queuemsg )
{
	bmsg_t bmsg;
	
	if(queuemsg.step == 1)
	{

		bmsg_t bmsg;
		bmsg.msg.type = 0;
		bmsg.msg.subtype = 0;
		bmsg.enable = 1;		
	}
	else if(queuemsg.step == 2)  
	{
		bmsg_t bmsg;
		bmsg.msg.type = 0;
		bmsg.msg.subtype = 1;  
		memcpy(bmsg.msg.values,registermsg.name,10);
		memcpy(bmsg.msg.values+10,registermsg.password,6);
		memcpy(bmsg.msg.values+16,registermsg.id,8);
		bmsg.enable = 1;	
	}
	
	return bmsg;
}

bmsg_t deal_login(queuemsg_t queuemsg )
{
	bmsg_t bmsg;
	
	if(queuemsg.step == 1)
	{

        g_step = 3;  //登录输入ID
		printf("please input id:");	
        fflush(stdout);	
		bmsg.enable = 0;
	}
	else if(queuemsg.step == 2)  
	{

		bmsg.msg.type = 1;
		bmsg.msg.subtype = 0;  
		memcpy(bmsg.msg.values,registermsg.id,8);
		memcpy(bmsg.msg.values+8,registermsg.password,6);
		bmsg.enable = 1;	
	}	
	
	return bmsg;
}

bmsg_t deal_find(queuemsg_t queuemsg )
{
	bmsg_t bmsg;
	
	if(queuemsg.step == 1)
	{
		bmsg.msg.type = 2;
		bmsg.msg.subtype = 0;  
		bmsg.enable = 1;	
	}	

	return bmsg;
}

bmsg_t deal_add(queuemsg_t queuemsg )
{
    bmsg_t bmsg;
	char tmp[1];
	if(queuemsg.step == 1)
	{
        g_step = 5;  //输入ID
		printf("please input frined id:");	
        fflush(stdout);	
		bmsg.enable = 0; 	
	}
    else if(queuemsg.step == 2)
	{
		bmsg.msg.type = 3;
		bmsg.msg.subtype = 0;  
		memcpy(bmsg.msg.values,registermsg.id,8);
		bmsg.enable = 1;		
		
	}		
	else if(queuemsg.step == 3)
	{
		g_step = 7;  //输入ID
		printf("please input frined id:");	
        fflush(stdout);	
		bmsg.enable = 0; 
		
	}
	else if (queuemsg.step == 4)
	{
		memcpy(tmp , queuemsg.msg.values , 1);
		if(tmp[0] == '1')
		{
			bmsg.msg.type = 3;
			bmsg.msg.subtype = 1; 	
			memcpy(bmsg.msg.values,registermsg.id,8);        
			bmsg.enable = 1; 			
		}
	    else
		{
			bmsg.msg.type = 3;
			bmsg.msg.subtype = 2; 
			memcpy(bmsg.msg.values,registermsg.id,8);	        
			bmsg.enable = 1; 
		}
	}
	
	return bmsg;
}


bmsg_t deal_state(queuemsg_t queuemsg )
{
    bmsg_t  bmsg; 
	return bmsg;
}


bmsg_t deal_chat(queuemsg_t queuemsg )
{
    bmsg_t  bmsg; 
    if(queuemsg.step == 1)
	{
		g_step = 9;  //输入ID
		printf ("please select ID of friend:");
		fflush(stdout);	
        bmsg.enable = 0; 			
	}
	else if (queuemsg.step == 2)
	{	
		    if (strcmp(registermsg.txt,"quit")==0) 
		    {
		    	g_step = 0;
		    	printf ("back to the main interface!\n");
		    	show_main_surface();
		    	bmsg.enable=0;
		    }
		    else
		    {
				bmsg.msg.type = 5;
				bmsg.msg.subtype = 0;  
				memcpy(bmsg.msg.values,frenid,8);
				memcpy(bmsg.msg.values+8,registermsg.txt,1006);
				bmsg.enable = 1;
				printf("please input msg（please enter quit）:\n");
				fflush(stdout);			    	
		    	g_step = 8;  //聊天界面
		    }  				  
 
	  
	}
	return bmsg;
}

bmsg_t deal_creatgro(queuemsg_t queuemsg )
{
	bmsg_t  bmsg; 
	static char flag=0;
	if (queuemsg.step == 1)
	{
		bmsg.enable = 0;
		printf("-------1 create group\n");
		printf("-------2 into group\n");
		printf("-------3 seek group\n");
		printf("-------4 group chat\n");
		g_step = 11; 
	}
	else if (queuemsg.step == 2)
	{
		flag = queuemsg.msg.values[0];

		printf("group name:");
		fflush(stdout);
        g_step = 12; 
		bmsg.enable = 0;
	}
	else if (queuemsg.step == 3)
	{ 
		memcpy(groname,queuemsg.msg.values,10);
		memcpy(bmsg.msg.values,queuemsg.msg.values,10);
		if(flag == '1')  //
		{
			bmsg.msg.type = 7;
			bmsg.msg.subtype = 0; 
			bmsg.enable = 1;
		}
		else if(flag == '2')
		{
			
			bmsg.msg.type = 7;
			bmsg.msg.subtype = 1; 
			bmsg.enable = 1;
				
		}
		else if(flag == '3')
		{
			
			bmsg.msg.type = 7;
			bmsg.msg.subtype = 2;
			bmsg.enable = 1; 
			
				
		}	
		else if(flag == '4')  //
		{
			bmsg.msg.type = 7;
			bmsg.msg.subtype = 3;
			g_step = 13; 
			bmsg.enable = 0;		
		}				
		
	}
	else if (queuemsg.step == 4)
	{
	    if (strcmp(registermsg.txt,"quit")==0) 
	    {
	    	bmsg.enable = 0; 	
	    	g_step = 0;
	    	printf ("back to the main interface!\n");
			show_main_surface();		
		}
	    
	    else
	    {
			bmsg.msg.type = 7;
			bmsg.msg.subtype = 3;
	    	memcpy(bmsg.msg.values,groname,10);
			memcpy(bmsg.msg.values+10,registermsg.txt,1006);
			bmsg.enable = 1; 
			printf("please input text（please enter quit):\n");
			fflush(stdout);  
	    	g_step = 14;
	    }		
		
	}
	return bmsg;
}
