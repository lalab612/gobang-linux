#ifndef _TOUCH_H_
#define _TOUCH_H_
#include "typev.h"
extern qin_t   qingrd  ;
extern point_t point;
extern ssize_t read_ts(int tsfd ,point_t *ppoint);

//extern ssize_t read_ts(int tsfd);
#endif