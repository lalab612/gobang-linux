#include <stdio.h>
#include <unistd.h>
#include <sys/ioctl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/mman.h>
#include <fcntl.h>

#include "myfb.h"

unsigned int foreground = 0x00FFFFFF;   // 前景色
unsigned int background = 0x00000000;   // 背景色

struct fb_fix_screeninfo finfo = {0};   // 固定属性
struct fb_var_screeninfo vinfo = {0};   // 可变属性

// 虚拟区映射到进程的起始地址
unsigned char *vbuf = NULL;

/**
 * 功能：  打开名为 lcd_name 的 LCD 
 * 参数：  lcd_name LCD 的设备文件名，如果为 NULL 
 *         则使用默认的设备文件名
 * 返回值：成功返回文件描述符，失败返回 -1
 **/
int open_fb(char *lcd_name)
{
	if (!lcd_name)
	{
		lcd_name = LCD_NAME;
	}

	return open(lcd_name, O_RDWR);
}

/**
 * 功能：  获取 LCD 的固定属性
 * 参数：  lcd   LCD 设备文件描述符
 *         finfo LCD 的固定属性指针
 * 返回值：成功返回 0，失败返回 -1
 **/
int get_fbfixinfo(int lcd, struct fb_fix_screeninfo *finfo)
{
	return ioctl(lcd, FBIOGET_FSCREENINFO, finfo);
}

/**
 * 功能：  获取 LCD 的可变属性
 * 参数：  lcd   LCD 设备文件描述符
 *         vinfo LCD 的可变属性指针
 * 返回值：成功返回 0，失败返回 -1
 **/
int get_fbvarinfo(int lcd, struct fb_var_screeninfo *vinfo)
{
	return ioctl(lcd, FBIOGET_VSCREENINFO, vinfo);
}

/**
 * 功能：  打印 LCD 的固定属性
 * 参数：  finfo LCD 的固定属性指针
 * 返回值：成功返回 0，失败返回 -1
 **/
int print_fbfixinfo(struct fb_fix_screeninfo *finfo)
{
	if (!finfo)
	{
		return -1;
	}

	printf("id              : %s\n", finfo->id);
	printf("显存起始地址    : %ld\n", finfo->smem_start);
	printf("显存大小        : %d\n", finfo->smem_len);
	printf("像素构成        : %d\n", finfo->type);
	printf("色彩构成        : %d\n", finfo->visual);
	printf("x 轴平移步长    : %d\n", finfo->xpanstep);
	printf("y 轴平移步长    : %d\n", finfo->ypanstep);
	printf("y 轴循环步长    : %d\n", finfo->ywrapstep);
	printf("扫描线大小      : %d\n", finfo->line_length);
	printf("默认映射内存地址: %ld\n", finfo->mmio_start);
	printf("默认映射内存大小: %d\n", finfo->mmio_len);

	return 0;
}

/**
 * 功能：  打印 LCD 的可变属性
 * 参数：  vinfo LCD 的可变属性指针
 * 返回值：成功返回 0，失败返回 -1
 **/
int print_fbvarinfo(struct fb_var_screeninfo *vinfo)
{
	if (!vinfo)
	{
		return -1;
	}

	printf("可见区的宽度分辨率        :%d\n", vinfo->xres);
	printf("可见区的高度分辨率        :%d\n", vinfo->yres);
	printf("虚拟区的宽度分辨率        :%d\n", vinfo->xres_virtual);
	printf("虚拟区的高度分辨率        :%d\n", vinfo->yres_virtual);
	printf("虚拟区到可见区的宽度偏移量:%d\n", vinfo->xoffset);
	printf("虚拟区到可见区的高度偏移量:%d\n", vinfo->yoffset);
	printf("色彩深度                  :%d\n", vinfo->bits_per_pixel);
	printf("灰阶（非 0 时）           :%d\n", vinfo->grayscale);
	printf("红色色彩位域:\n");
	printf("\t偏移量 :%d\n", vinfo->red.offset);
	printf("\t长度   :%d\n", vinfo->red.length);
	printf("\tMSB    :%d\n", vinfo->red.msb_right);
	printf("绿色色彩位域:\n");
	printf("\t偏移量 :%d\n", vinfo->green.offset);
	printf("\t长度   :%d\n", vinfo->green.length);
	printf("\tMSB    :%d\n", vinfo->green.msb_right);
	printf("蓝色色彩位域:\n");
	printf("\t偏移量 :%d\n", vinfo->blue.offset);
	printf("\t长度   :%d\n", vinfo->blue.length);
	printf("\tMSB    :%d\n", vinfo->blue.msb_right);
	printf("透明度色彩位域:\n");
	printf("\t偏移量 :%d\n", vinfo->transp.offset);
	printf("\t长度   :%d\n", vinfo->transp.length);
	printf("\tMSB    :%d\n", vinfo->transp.msb_right);
	printf("设置参数生效时机          :%d\n", vinfo->activate);
	printf("图片高度（单位：毫米）    :%d\n", vinfo->height);
	printf("图片宽度（单位：毫米）    :%d\n", vinfo->width);

	return 0;
}

/**
 * 功能：  初始化 framebuffer，即获取固定属性和可变属性
 * 参数：  lcd_name LCD 设备文件名
 * 返回值：成功返回 LCD 设备文件描述符，失败返回 -1
 **/
int init_fb(char *lcd_name)
{
	int lcd;
	size_t vsize;

	lcd = open_fb(lcd_name);
	if (-1 == lcd)
	{
		perror("打开 LCD 设备文件失败");
		return -1;
	}
	// finfo
	if (-1 == get_fbfixinfo(lcd, &finfo))
	{
		perror("获取 LCD 固定属性失败");
		close(lcd);
		return -1;
	}

	// vinfo
	if (-1 == get_fbvarinfo(lcd, &vinfo))
	{
		perror("获取 LCD 可变属性失败");
		close(lcd);
		return -1;
	}

	// vbuf
	// 虚拟区总字节数
	vsize = vinfo.xres_virtual * vinfo.yres_virtual * 
		(vinfo.bits_per_pixel / 8);
	if (MAP_FAILED == (vbuf = mmap(NULL, vsize, PROT_READ | PROT_WRITE, 
						MAP_SHARED, lcd, 0)))
	{
		perror("映射虚拟区失败");
		close(lcd);
		vbuf = NULL;
		return -1;
	}

	return lcd;
}

/**
 * 功能：  销毁 framebuffer，即释放映射的内存，清空属性变量
 * 参数：  无
 * 返回值：成功返回 0，失败返回 -1
 **/
int destroy_fb(void)
{
	// 释放映射的内存
	return munmap(vbuf, vinfo.xres_virtual * vinfo.yres_virtual 
				* vinfo.bits_per_pixel / 8);
}

/**
 * 功能：  设置前景色为 color
 * 参数：  color 前景色 
 * 返回值：无
 **/
void set_fg(unsigned int color)
{
	foreground = color;
}

/**
 * 功能：  设置背景色为 color
 * 参数：  color 背景色 
 * 返回值：无
 **/
void set_bg(unsigned int color)
{
	background = color;
}

/**
 * 功能：  设置背景色为 bc，前景色为 fc 
 * 参数：  bc 背景色
 *         fc 前景色
 * 返回值：无
 **/
void set_ground(unsigned int bc, unsigned int fc)
{
	background = bc;
	foreground = fc;
}

/**
 * 功能：  在视图 view 上画矩形 rect 的边框
 * 参数：  view 视图指针
 *         rect 矩形指针
 * 返回值：无
 **/
void draw_rect_border(view_t *view, rect_t *rect)
{
	int i, j;
	int bytes = vinfo.bits_per_pixel / 8;
	int xoffset, yoffset;

	xoffset = vinfo.xoffset + view->xoffset + rect->xoffset;
	yoffset = vinfo.yoffset + view->yoffset + rect->yoffset;

	for (i = 0; i < rect->height; i++)
	{
		// view 中的行超出虚拟区的部分不处理
		// rect 中的行超出 view 的部分不处理
		if ((i + yoffset < 0) 
					|| (i + yoffset >= vinfo.yres_virtual)
					|| (i + rect->yoffset < 0)
					|| (i + rect->yoffset >= view->height))
		{
			continue;
		}

		for (j = 0; j < rect->width; j++)
		{
			// view 中的列超出虚拟区的部分不处理
			// rect 中的列超出 view 的部分不处理
			if ((j + xoffset < 0)
						|| (j + xoffset >= vinfo.xres_virtual)
						|| (j + rect->xoffset < 0)
						|| (j + rect->xoffset >= view->width))
			{
				continue;
			}

			// i 行 j 列的点在边框上则着色
			if (((i < rect->border_size) 
							|| (i >= rect->height - rect->border_size)) 
						|| ((j < rect->border_size) 
							|| (j >= rect->width - rect->border_size)))
			{
				int r = yoffset + i;
				int c = xoffset + j;
				int offset = (r * vinfo.xres_virtual + c) * bytes;
				*((unsigned int *)(vbuf + offset)) = rect->border_color;
			}
		}
	}
}

/**
 * 功能：  在视图 view 上填充矩形 rect
 * 参数：  view 视图指针
 *         rect 矩形指针
 * 返回值：无
 **/
void fill_rect(view_t *view, rect_t *rect)
{
	int i, j;
	int bytes = vinfo.bits_per_pixel / 8;
	int xoffset, yoffset;

	xoffset = vinfo.xoffset + view->xoffset + rect->xoffset;
	yoffset = vinfo.yoffset + view->yoffset + rect->yoffset;

	for (i = 0; i < rect->height; i++)
	{
		// view 中的行超出虚拟区的部分不处理
		// rect 中的行超出 view 的部分不处理
		if ((i + yoffset < 0) 
					|| (i + yoffset >= vinfo.yres_virtual)
					|| (i + rect->yoffset < 0)
					|| (i + rect->yoffset >= view->height))
		{
			continue;
		}

		for (j = 0; j < rect->width; j++)
		{	
			// view 中的列超出虚拟区的部分不处理
			// rect 中的列超出 view 的部分不处理
			if ((j + xoffset < 0)
						|| (j + xoffset >= vinfo.xres_virtual)
						|| (j + rect->xoffset < 0)
						|| (j + rect->xoffset >= view->width))
			{
				continue;
			}

			// i 行 j 列的点在边框内则填充色
			if (((i >= rect->border_size) 
							&& (i < rect->height - rect->border_size)) 
						&& ((j >= rect->border_size) 
							&& (j < rect->width - rect->border_size)))
			{
				int r = yoffset + i;
				int c = xoffset + j;
				int offset = (r * vinfo.xres_virtual + c) * bytes;
				*((unsigned int *)(vbuf + offset)) = rect->fill_color;
			}
		}
	}
}

/**
 * 功能：  在视图 view 上画矩形 rect
 * 参数：  view 视图指针
 *         rect 矩形指针
 * 返回值：无
 **/
void draw_rect(view_t *view, rect_t *rect)
{
	int i, j;
	int bytes = vinfo.bits_per_pixel / 8;
	int xoffset, yoffset;

	xoffset = vinfo.xoffset + view->xoffset + rect->xoffset;
	yoffset = vinfo.yoffset + view->yoffset + rect->yoffset;

	for (i = 0; i < rect->height; i++)
	{
		// view 中的行超出虚拟区的部分不处理
		// rect 中的行超出 view 的部分不处理
		if ((i + yoffset < 0) 
					|| (i + yoffset >= vinfo.yres_virtual)
					|| (i + rect->yoffset < 0)
					|| (i + rect->yoffset >= view->height))
		{
			continue;
		}

		for (j = 0; j < rect->width; j++)
		{
			int r = yoffset + i;
			int c = xoffset + j;
			int offset = (r * vinfo.xres_virtual + c) * bytes;

			// view 中的列超出虚拟区的部分不处理
			// rect 中的列超出 view 的部分不处理
			if ((j + xoffset < 0)
						|| (j + xoffset >= vinfo.xres_virtual)
						|| (j + rect->xoffset < 0)
						|| (j + rect->xoffset >= view->width))
			{
				continue;
			}

			// i 行 j 列的点在边框上则着色
			if (((i < rect->border_size) 
							|| (i >= rect->height - rect->border_size)) 
						|| ((j < rect->border_size) 
							|| (j >= rect->width - rect->border_size)))
			{
				*((unsigned int *)(vbuf + offset)) = rect->border_color;
			}
			// 在边框内则填充色
			else
			{
				*((unsigned int *)(vbuf + offset)) = rect->fill_color;
			}
		}
	}
}

/**
 * 功能：  在视图 view 上画图片 image
 * 参数：  view  视图指针
 *         image 图片指针
 * 返回值：无
 **/
void draw_image(view_t *view, image_t *image)
{
	int i, j;
	int bytes = vinfo.bits_per_pixel / 8;
	int xoffset, yoffset;

	xoffset = vinfo.xoffset + view->xoffset + image->xoffset;
	yoffset = vinfo.yoffset + view->yoffset + image->yoffset;

	for (i = 0; i < image->height; i++)
	{
		// view 中的行超出虚拟区的部分不处理
		// image 中的行超出 view 的部分不处理
		if ((i + yoffset < 0) 
					|| (i + yoffset >= vinfo.yres_virtual)
					|| (i + image->yoffset < 0)
					|| (i + image->yoffset >= view->height))
		{
			continue;
		}

		for (j = 0; j < image->width; j++)
		{
			int r = yoffset + i;   // i 行 j 列像素上方的行数
			int c = xoffset + j;   // i 行 j 列像素左边的像素个数
			// i 行 j 列像素在虚拟区中字节偏移量
			int offset = (r * vinfo.xres_virtual + c) * bytes;
			// i 行 j 列像素在图片中的字节偏移量
			int img_offset = (i * image->width + j) * 4;

			// view 中的列超出虚拟区的部分不处理
			// image 中的列超出 view 的部分不处理
			if ((j + xoffset < 0)
						|| (j + xoffset >= vinfo.xres_virtual)
						|| (j + image->xoffset < 0)
						|| (j + image->xoffset >= view->width))
			{
				continue;
			}
			
			*((unsigned int *)(vbuf + offset)) = 
				*((unsigned int *) (image->data + img_offset));
		}
	}
}

