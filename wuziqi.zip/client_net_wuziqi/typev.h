#ifndef   _TYPEV_H_
#define   _TYPEV_H_

#ifdef GLOBLE_VAR
	#define EXTERN  
#else
    #define EXTERN  extern
#endif

#define NOQIN   0
#define WHITE   1
#define BLACK   2

#define NET   1
#define HOME  2

EXTERN int *lcd;

typedef struct 
{
	int x ;
	int y ;
	int handup_flag;
}point_t;

typedef struct 
{
     char   touchgrd[12][12]; 
     char   showgrd[12][12]; 
     char   qincolor;  
     char   next;    //清屏，下一局 
	 char   enable;
	 
}qin_t;

typedef struct 
{
	unsigned char type;
	unsigned char leng[4];
	unsigned char subtype;
	unsigned char retain[4];
	unsigned char values[1014];
}msg_t;

typedef struct 
{
	char    enable;
	msg_t   msg;
	char    ip[16];
	int     port;     // 客户端端口
    int    	confd;
	
}bmsg_t;


typedef struct 
{
    msg_t  		msg;
	point_t     point;
	char        type;
	char        subtype;
    int    		confd;

}queuemsg_t;


#endif