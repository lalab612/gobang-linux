#ifndef _WUQIN_H_
#define _WUQIN_H_

extern int  g_fbfd , g_tsfd ;

#define WHITE_QIN_PATH     "/wuqin/wchess.bmp"

#define BLACK_QIN_PATH     "/wuqin/bchess.bmp"
#endif