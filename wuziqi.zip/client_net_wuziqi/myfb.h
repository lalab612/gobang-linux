
#ifndef _MYFB_H_
#define _MYFB_H_

#include <linux/fb.h>

#define LCD_NAME "/dev/fb0"

extern unsigned int foreground;   // 前景色
extern unsigned int background;   // 背景色

extern struct fb_fix_screeninfo finfo;   // 固定属性
extern struct fb_var_screeninfo vinfo;   // 可变属性

// 虚拟区映射到进程的起始地址
extern unsigned char *vbuf;

// 定义视图结构体类型
typedef struct
{
	int xoffset;      // 基于可见区的横向偏移量(像素)
	int yoffset;      // 基于可见区的纵向偏移量(像素)
	int width;        // 宽度(像素)
	int height;       // 高度(像素)
	unsigned int fg;  // 视图前景色
	unsigned int bg;  // 视图背景色
} view_t;

// 定义矩形结构体类型
typedef struct 
{
	int xoffset;      // 基于所在视图的横向偏移量(像素)
	int yoffset;      // 基于所在视图的纵向偏移量(像素)
	int width;        // 宽度
	int height;       // 高度
	int border_size;  // 边框厚度
	int border_color; // 边框色
	int fill_color;   // 填充色
} rect_t;

// 定义图片结构体类型
typedef struct 
{
	int xoffset;      // 基于所在视图的横向偏移量(像素)
	int yoffset;      // 基于所在视图的纵向偏移量(像素)
	int width;        // 宽度
	int height;       // 高度
	unsigned char *data;  // 图片像素颜色数据
}image_t;

/**
 * 功能：  打开名为 lcd_name 的 LCD 
 * 参数：  lcd_name LCD 的设备文件名，如果为 NULL 
 *         则使用默认的设备文件名
 * 返回值：成功返回文件描述符，失败返回 -1
 **/
int open_fb(char *lcd_name);

/**
 * 功能：  获取 LCD 的固定属性
 * 参数：  lcd   LCD 设备文件描述符
 *         finfo LCD 的固定属性指针
 * 返回值：成功返回 0，失败返回 -1
 **/
int get_fbfixinfo(int lcd, struct fb_fix_screeninfo *finfo);
		
/**
 * 功能：  获取 LCD 的可变属性
 * 参数：  lcd   LCD 设备文件描述符
 *         vinfo LCD 的可变属性指针
 * 返回值：成功返回 0，失败返回 -1
 **/
int get_fbvarinfo(int lcd, struct fb_var_screeninfo *vinfo);
		
/**
 * 功能：  打印 LCD 的固定属性
 * 参数：  finfo LCD 的固定属性指针
 * 返回值：成功返回 0，失败返回 -1
 **/
int print_fbfixinfo(struct fb_fix_screeninfo *finfo);

/**
 * 功能：  打印 LCD 的可变属性
 * 参数：  vinfo LCD 的可变属性指针
 * 返回值：成功返回 0，失败返回 -1
 **/
int print_fbvarinfo(struct fb_var_screeninfo *vinfo);

/**
 * 功能：  初始化 framebuffer，即获取固定属性和可变属性
 * 参数：  lcd_name LCD 设备文件名
 * 返回值：成功返回 LCD 设备文件描述符，失败返回 -1
 **/
int init_fb(char *lcd_name);

/**
 * 功能：  销毁 framebuffer，即释放映射的内存，清空属性变量
 * 参数：  无
 * 返回值：成功返回 0，失败返回 -1
 **/
int destroy_fb(void);

/**
 * 功能：  设置前景色为 color
 * 参数：  color 前景色 
 * 返回值：无
 **/
void set_fg(unsigned int color);

/**
 * 功能：  设置背景色为 color
 * 参数：  color 背景色 
 * 返回值：无
 **/
void set_bg(unsigned int color);

/**
 * 功能：  设置背景色为 bc，前景色为 fc 
 * 参数：  bc 背景色
 *         fc 前景色
 * 返回值：无
 **/
void set_ground(unsigned int bc, unsigned int fc);

/**
 * 功能：  在视图 view 上画矩形 rect 的边框
 * 参数：  view 视图指针
 *         rect 矩形指针
 * 返回值：无
 **/
void draw_rect_border(view_t *view, rect_t *rect);

/**
 * 功能：  在视图 view 上填充矩形 rect
 * 参数：  view 视图指针
 *         rect 矩形指针
 * 返回值：无
 **/
void fill_rect(view_t *view, rect_t *rect);

/**
 * 功能：  在视图 view 上画矩形 rect
 * 参数：  view 视图指针
 *         rect 矩形指针
 * 返回值：无
 **/
void draw_rect(view_t *view, rect_t *rect);

/**
 * 功能：  在视图 view 上画图片 image
 * 参数：  view  视图指针
 *         image 图片指针
 * 返回值：无
 **/
void draw_image(view_t *view, image_t *image);

#endif

