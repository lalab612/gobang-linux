#ifndef _HEAD_H_
#define _HEAD_H_

extern bmsg_t deal_data(queuemsg_t queuemsg );
#endif 