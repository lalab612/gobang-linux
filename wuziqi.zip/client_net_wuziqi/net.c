#include "typev.h"
#include "uinsock.h"
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <stdio.h>
#include <string.h>


#define BROAD_IP      "192.168.0.255"
#define SERVER_PORT   6000

int tcpsockfd ;

char netcolor;

/*********************************************
���ܣ�ͨ���㲥��ȡIP������IP��ַ



***********************************************/

int init_net()
{
	struct sockaddr_in   svr_addr, clt_addr;	
	socklen_t socklen =  sizeof svr_addr;
	in_addr_t inaddr;
	int port ;
	int broadcast=1;   // �� 0 ��ʾ���ù㲥��0 ��ʾȡ���㲥	
	char *ip;
	
   // ���� UDP �׽���
	int udpsockfd = socket(AF_INET /*PF_INET*/, SOCK_DGRAM, 0);
	
	if (-1 == udpsockfd)
	{
		perror("failed to create udpsockfd!");
		return -1;
	}

	// ���ù㲥ѡ��
	if (-1 == setsockopt(udpsockfd, SOL_SOCKET, SO_BROADCAST, //broadcast=1;   // �� 0 ��ʾ���ù㲥��0 ��ʾȡ���㲥
					&broadcast, sizeof(int)))
	{
		perror("failed to set broatcast options!\n");
	}
	
	// ���ý����ߵ�ַ
	inaddr = inet_addr(BROAD_IP);
	if (INADDR_NONE == inaddr)
	{
		printf("%s is false IP\n", BROAD_IP);
		
	}
	svr_addr.sin_family = AF_INET;
	svr_addr.sin_port = htons(SERVER_PORT);
	svr_addr.sin_addr.s_addr = inaddr;
	
	//������Ϣ
	msg_t  msg;
	
	memset((char *)&msg , 0 ,sizeof msg);
	msg.type = 6 ;
	msg.subtype = 0;
	// �㲥����
	if (-1 == sendto(udpsockfd, (char *)&msg , 1024, 0, 
					(struct sockaddr *) &svr_addr, socklen))
	{
		perror("send error!");
		return -1;
		
	}
	printf("send success!\n");
	
	//���
	memset((char *)&msg , 0 ,sizeof msg);
	// �㲥���շ�������IP
	if (-1 == recvfrom(udpsockfd, (char *)&msg , 1024, 0, 
					(struct sockaddr *) &clt_addr, &socklen))
	{
		perror("receive error!\n");
	}	
	printf("receving %s(%d) send message��%d\t%d\n", 
				inet_ntoa(clt_addr.sin_addr), 
				ntohs(clt_addr.sin_port), msg.type,msg.subtype);

    if (msg.type == 6 && msg.subtype == 0)
    {
        printf ("receive server IP success!\n");
        close(udpsockfd);
    }
    else 
    {
        printf ("server close!\n");
        close(udpsockfd);
    }

    //tcp����
    ip = inet_ntoa(clt_addr.sin_addr);
    port = ntohs(clt_addr.sin_port);
	
	
	// �����׽��֣������ӷ�����
	if (-1 == (tcpsockfd = uin_connect(ip, port)))
	{
		printf("uin_connect() error\n");
		return -1;
	}
	return 0;
}











