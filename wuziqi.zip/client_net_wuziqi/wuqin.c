#define  GLOBLE_VAR
#include <unistd.h>
#include <stdio.h>
#include <string.h>
#include <wchar.h>

#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>

#include <pthread.h>

#include <sys/types.h>
#include <sys/stat.h>  
#include <fcntl.h>
#include <sys/mman.h>
#include <wchar.h>

#include "uinsock.h"
#include "touch.h"
#include "readbmp.h"

#include <errno.h>

#include "myfb.h"
#include "typev.h"
#include "wuqin.h"
#include "lcd_app.h"
#include "locale.h"
#include "net.h"
#include "deal.h"
#include "queue.h"


void *handle_server_recv(void *arg);
void *handle_server_send(void *arg);
void *handle_touch(void *arg);

// �����
volatile int amount = 0;
queue_t queue;
queuemsg_t   queuemsg;
// ������
pthread_mutex_t mutex = PTHREAD_MUTEX_INITIALIZER;
// ��������
pthread_cond_t cond = PTHREAD_COND_INITIALIZER;

int  g_fbfd , g_tsfd ;

int  main()
{
	pthread_t pthread1 , pthread2 , pthread3;	
	int  cnt ;
	struct fb_var_screeninfo vinfo;

	 setlocale(LC_CTYPE, "zh_CN.utf8");
	//��ȡLCD�豸��Ϣ ��ʼ���ֿ�
	get_lcd_info();	
		
	//�򿪴������豸 
	g_tsfd = open("/dev/input/event0",O_RDWR);
	if(g_tsfd < 0)
	{
		perror("");
		return -1;
	}

	//��LCD�豸
	g_fbfd = open("/dev/fb0",O_RDWR);	
	if(g_fbfd < 0)
	{
		printf("open lcd fail\n");
		return -1;
	}
	get_fbvarinfo(g_fbfd , &vinfo);
	print_fbvarinfo(&vinfo);
	
	//��LCD�豸����ӳ�����
	lcd = mmap(NULL,800*480*4,PROT_READ|PROT_WRITE,MAP_SHARED,g_fbfd,0);
	// 
	if (NULL == lcd)
	{
		perror("mmap fail \n");
		return -1;
	}
	
	init_net();

	printf("read bmp end\n");
    while (1)
    {        
        if (pthread_create(&pthread1, NULL, handle_server_recv, (void *)tcpsockfd))
        {
            printf("failed to creat pthread read!\n");
            return -1;
        }
        if (pthread_create(&pthread2, NULL, handle_server_send, (void *)tcpsockfd))
        {
            printf("failef to creat pthread write!\n");
            pthread_detach(pthread1);   //����߳�2�������ɹ�����ر��߳�1	
            return -1;
        }
        if (pthread_create(&pthread3, NULL, handle_touch, (void *)0))
        {
            printf("failef to creat pthread write!\n");
            pthread_detach(pthread1);   //����߳�2�������ɹ�����ر��߳�1
            pthread_detach(pthread2);   //����߳�2�������ɹ�����ر��߳�1
            return -1;
        }	

        // �������߳�
        pthread_detach(pthread1);
        pthread_detach(pthread2);
        pthread_detach(pthread3);	
        //-------------------------	
        
        queuemsg.point.x=0;
        queuemsg.point.y=0;
        
        init_show();	
        
        while (1)
        {
            show_qinq();
            
            int win;
            
            if ( 0 != (win = show_judge()) )
            {
                if(WHITE == win)
                {
                  wchar_t *p1 =L"Congratulate ! ";	
                  Lcd_Show_FreeType(lcd,p1,30,0x00ff0000,0,0,550,250);
                  wchar_t *p2 =L"---white is---";	
                  Lcd_Show_FreeType(lcd,p2,30,0xff0000,0,0,550,280);
                  wchar_t *p3 =L"---winner---";	
                  Lcd_Show_FreeType(lcd,p3,30,0xff0000,0,0,550,310);			  
                }
                else if(BLACK == win)
                {
                  wchar_t *p1 =L"Congratulate ! ";	
                  Lcd_Show_FreeType(lcd,p1,30,0xff0000,0,0,550,250);
                  wchar_t *p2 =L"---black is---";	
                  Lcd_Show_FreeType(lcd,p2,30,0xff0000,0,0,550,280);
                  wchar_t *p3 =L"----Winner---";	
                  Lcd_Show_FreeType(lcd,p3,30,0xff0000,0,0,550,310);	
            
                }
                
                while(1)
                {
                    if( 1 == qingrd.next)
                    {
                        init_show();
                        qingrd.next = 0;
                        memset((char *)&qingrd , 0 , sizeof qingrd);
                        break;
                    }
                }
                
            }
            
            if( 1 == qingrd.next)
            {
                init_show();
                qingrd.next = 0;
                memset((char *)&qingrd , 0 , sizeof qingrd);
            }
            
        }
    }
}


void *handle_server_send(void *arg)
{
	int connfd = (int) arg;
	int nfds = connfd + 1;	
	int sendconfd ;
	int cnt;

	bmsg_t bmsg;
	
	while(1)
	{
		//����
		pthread_mutex_lock(&mutex);	
		
		amount = get_length(&queue);
		
		while (1 > amount)
		{
			pthread_cond_wait(&cond, &mutex);
		}	
		
		dequeue(&queue, &queuemsg);  //����
		
        //��������
		bmsg = deal_data(queuemsg);
		
		if(bmsg.enable)
		{
			sendconfd  = connfd;			

			if (-1 == (cnt = n_send(sendconfd, (char *)&bmsg.msg, 1024)))
			{
				printf("send error!\n");
				//break;
			}
			else if (0 == cnt)
			{
				printf("server cloose!\n");
				//break;
			}
            else
			{
				printf("send \n");
				printf("%d\n",bmsg.msg.type);
				printf("%d\n",bmsg.msg.subtype);
			}				
		}		// ����
		
		pthread_mutex_unlock(&mutex);	
		
		//pthread_yield();
	}	
}




void *handle_server_recv(void *arg)
{
	int connfd = (int) arg;
	fd_set rset;
	
	int nfds = connfd + 1;	
	
	while (1)
	{
		char rbuf[1024] = "";
		int cnt;
		// �����������
		FD_ZERO(&rset);
		// ��������������������
		FD_SET(connfd, &rset);		
		// ��

		//�����ӿ��Ƿ�������
		while ((-1 == select(nfds, &rset, NULL, NULL, NULL))
					&& errno == EINTR);	
		printf("receive \n");	
		//����
		pthread_mutex_lock(&mutex);				
		//����		
		if (FD_ISSET(connfd, &rset))   // �ɶ���
		{
			// ��
			if (-1 == (cnt = r_recv(connfd, rbuf, 1024)))
			{
				printf("receive error!\n");
				break;
			}
			else if (0 == cnt)
			{
				printf("server close!\n");
				break;
			}
			memcpy(&queuemsg.msg , rbuf , 1024);
			printf ("%d\n",queuemsg.msg.type);
			printf ("%d\n",queuemsg.msg.subtype);
			printf ("%s\n",queuemsg.msg.values);
			queuemsg.type = 1;
		    enqueue(&queue, &queuemsg);  //���
		    amount++;		
		}		
	    // ����
		pthread_mutex_unlock(&mutex);
		
		// ֪ͨ�ȴ������������߳�
		pthread_cond_broadcast(&cond);
	}

_out:
	printf("pthread number: %ld over!\n", pthread_self());
	close(connfd);

	return NULL;
}

void *handle_touch(void *arg)
{
//	int tsfd = (int) arg;
	fd_set rset;
	msg_t msg;
	int nfds = g_tsfd + 1;	 //touch
	point_t   m_point;
	while (1)
	{
		int cnt;
		
		// �����������
		FD_ZERO(&rset);
		// ��������������������
		FD_SET(g_tsfd, &rset);		

		//�����ӿ��Ƿ�������
		while ((-1 == select(nfds, &rset, NULL, NULL, NULL))
					&& errno == EINTR);	
			printf("write \n");	
	    //����
	    pthread_mutex_lock(&mutex);	
		
		if (FD_ISSET(g_tsfd, &rset))   // �ɶ���
		{	
		    m_point.handup_flag = 0;
		   
            read_ts(g_tsfd , &m_point);
			
			if( 1 == m_point.handup_flag)
			{
				// ��
				queuemsg.type = 2;
				queuemsg.point = m_point;
				enqueue(&queue, &queuemsg);  //���
				amount++;	
			}		
		}
		// ����
		pthread_mutex_unlock(&mutex);
		// ֪ͨ�ȴ������������߳�
		pthread_cond_broadcast(&cond);	
	}

_out:
	printf("pthread number :%ld over!\n", pthread_self());
//	close(connfd);

	return NULL;
}


















