#include <stdio.h>
#include "typev.h"
#include <unistd.h>

#include <sys/types.h>
#include <sys/stat.h>  
#include <fcntl.h>
#include "mcommon.h"
#include "wuqin.h"
#include "touch.h"
#include <wchar.h>
#include "lcd_app.h"


/*******************************************
���ܣ���������ʾbmp�ļ�
������
    filename:bmp�ļ�·��
	offset_x:��ʾͼƬ�������ʾ�����Ͻǵ�x��ƫ����
	offset_y:��ʾͼƬ�������ʾ�����Ͻǵ�y��ƫ����
	show_type:     1:��Բ����ʾ   2:�Է�����ʾ
����ֵ:
*********************************************/
int read_bmp(char *filename ,int offset_x , int offset_y , char show_type)
{
	int cnt ;
	//��ͼƬ�ļ� 
	int bmpfd = open(filename,O_RDWR);
		
	if(bmpfd < 0)
	{
		printf("open path %s fail\n",filename);
		perror("");
		return -1;
	}
	//��ȡͼƬ��ͷ��Ϣ 
	unsigned char head[54]={0};
		
	if( -1 == safe_read(bmpfd , head , 54))
	{
		return -1;
	}
	
			
	//��������  
	int  kuan = *((int *)&head[18]);
	int  gao  = *((int *)&head[22]);
	
	printf("kuan = %d\n",kuan);
	printf("gao  = %d\n",gao);
		
	//�䳤���� 
	int  buf[gao][kuan];//32λͼ��buf
	char tmp_buf[gao*kuan*4]; //24λͼ��buf
	//��ȡ�ļ������ݵ� buf��  
	if( -1 == safe_read(bmpfd , tmp_buf , sizeof(tmp_buf)))
	{
		return -1;
	}		
							
	unsigned char r=0;
	unsigned char g=0;
	unsigned char b=0;
	unsigned char a=0;
	unsigned char *p = tmp_buf;
	unsigned int color = 0;
	int x=0,y=0;
	int mx =0 ,my = 0; 
		
		
	for( y = 0 ; y < gao ; y++)
	{
		for( x = 0 ; x < kuan ; x++)
		{
			b = *p++;
			g = *p++;
			r = *p++;
			a = *p++;
			color  = a << 24 | r << 16 | g << 8 | b;
			
			buf[y][x] = color;//������ɫֵ

			//��ֹԽ��,���Խ���ˣ��Ͳ���ʾ
			if(x >= 800 || y >=480 )
			{
				continue;
			}
			
			if(x + offset_x >= 800 || y + offset_y >=480 )
			{
				continue;
			}			
	        if( 2 == show_type) //�Է�����ʾͼƬ
			{
				*(lcd + (y + offset_y)*800 + (x + offset_x) ) = buf[y][x];  //��ʾ��ɫֵ
			}
			else if( 1 == show_type)  //��ͼ����ʾͼƬ
			{
				*(lcd + (y + offset_y)*800 + (x + offset_x) ) = buf[y][x];  //��ʾ��ɫֵ
			}
	
		}
		//printf("y  = %d\n",y);
	}
	close(bmpfd);
	
}




int show_qinq()
{
	int i , j;
	
	for( i = 0 ; i < 12 ; i++)
	{
		for( j = 0 ; j < 12 ; j++)
		{
			
			if(( NOQIN != qingrd.touchgrd[i][j])&&(NOQIN == qingrd.showgrd[i][j]))
			{
				if( WHITE == qingrd.qincolor )
				{
					read_bmp(WHITE_QIN_PATH , j * 40 , i*40 ,2);
					qingrd.showgrd[i][j] = WHITE;   //��ֹ�ظ���ͼ
				}
				else if( BLACK == qingrd.qincolor )
				{
					read_bmp(BLACK_QIN_PATH , j * 40 , i*40 ,2);
					qingrd.showgrd[i][j] = BLACK;
				}
			}
		}
	}
}


int judge_one(char color , int x , int y)
{
	if(( x < 12 )&&( x >= 0 )&& (y >=0) && ( y < 12 ))
	{
		if(  color == qingrd.showgrd[y][x] )//���ӵ��ڴ����ɫ
		{
			return 1;
		}
		else
		{
			return 0;
		}
		
	}
	else
	{
		return 0;
	}
}


int show_judge()
{
	int x , y , z;
	int txstr ,tystr;
	int xstr[8] , ystr[8];
	int i;
	int num;
	
    z = 0;
    for(y = -1 ;y <= 1 ; y++)
	{
		for(x = -1 ; x <= 1 ; x++)
		{
			if(( 0 == y)&&( 0 == x))
			{
				continue;
			}
			xstr[z] = x;
			ystr[z] = y;
			z++ ;
		}
	}
	 
	for( y = 0 ; y < 12 ; y++)
	{
		for( x = 0 ; x < 12 ; x++)
		{
			if( WHITE == qingrd.showgrd[y][x]) //����˵�Ϊ����
			{
				for(z = 0 ; z < 8 ; z ++)   //��8������
				{
					txstr = 0 ; 
					tystr = 0 ; 
					num = 0;
					for(i = 0 ; i < 4 ; i++)  //ÿ������4���ۼ�
					{
						txstr = txstr + xstr[z];
						tystr = tystr + ystr[z];
						if( 0 == judge_one(WHITE , x + txstr , y + tystr ))
						{
							break;
						}
						num++;
					}
					if( 4 == num )
					{
						 printf("white you win!\n");		
						return WHITE;
					}
                   			
				}
			}
			
			if( BLACK == qingrd.showgrd[y][x]) //����˵�Ϊ����
			{
				for(z = 0 ; z < 8 ; z ++)   //��8������
				{
					txstr = 0 ; 
					tystr = 0 ; 
					num = 0;
					for(i = 0 ; i < 4 ; i++)  //ÿ������4���ۼ�
					{
						txstr = txstr + xstr[z];
						tystr = tystr + ystr[z];
						if( 0== judge_one(BLACK , x + txstr , y + tystr ))
						{
							break;
						}
						num++;
					}
					if( 4 == num )
					{
						printf("black you win!\n");	
						return BLACK;
					}
                    				
				}
			}			
		}
	}
	
	return 0;
}



void init_show()
{
	qingrd.qincolor = WHITE;
	read_bmp("/wuqin/board800480.bmp" , 0 , 0 , 2);
	read_bmp(WHITE_QIN_PATH , 540 , 80 , 2);
	read_bmp(BLACK_QIN_PATH , 700 , 80 , 2);
	
	wchar_t *p =L"Choose your flag first";	
	Lcd_Show_FreeType(lcd,p,28,0x00ff00,0,0,500,40);
    
	wchar_t *pnext =L"give up/next";	
	Lcd_Show_FreeType(lcd,pnext,28,0x00ff00,0,0,630,460);
    
    wchar_t *request =L"request";	
	Lcd_Show_FreeType(lcd,request,28,0x00ff00,0,0,480,460);
}



