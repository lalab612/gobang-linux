#ifndef _NET_H_
#define _NET_H_

extern int tcpsockfd ,udpsockfd ,g_connfd;
extern bmsg_t deal_data(queuemsg_t queuemsg);
extern char netcolor;
extern int init_net();
#endif