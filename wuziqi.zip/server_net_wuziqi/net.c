#include "typev.h"
#include "uinsock.h"
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <stdio.h>
#include <string.h>


#define BROAD_IP      "192.168.0.255"
#define SERVER_PORT   6000

int tcpsockfd ,udpsockfd ,g_connfd;

char netcolor;

/*********************************************
���ܣ�ͨ���㲥��ȡIP������IP��ַ



***********************************************/

int init_net()
{
	struct sockaddr_in clt_addr;	
	int port = 6000;
    //---------------------------------------------tcp
	if (-1 == (tcpsockfd = uin_open_tcp(port)))
	{
		printf("uin_open_tcp() ʧ��\n");
		return -1;
	}
     printf("tcpfd :%d \n" ,tcpsockfd);
	// --------------------------------------------udp


	if (-1 == (g_connfd = uin_accept(tcpsockfd, &clt_addr)))
	{
		printf("uin_accpet() ʧ��\n");
		return -1;
	}
	printf("client %s (%d)connect success\n", 
				inet_ntoa(clt_addr.sin_addr),
				ntohs(clt_addr.sin_port));
	
	  printf("connect \n" );
	return 0;
}











