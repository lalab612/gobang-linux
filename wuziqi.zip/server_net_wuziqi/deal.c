#include "typev.h"
#include "wuqin.h"
#include "lcd_app.h"
#include "locale.h"
#include "net.h"
#include "touch.h"
#include "readbmp.h"

unsigned char color1=0,color2=0;

bmsg_t deal_recive_data(queuemsg_t queuemsg );//�������յ�������
bmsg_t deal_touch_data(queuemsg_t queuemsg );

bmsg_t deal_data(queuemsg_t queuemsg )
{
	bmsg_t  bmsg;
	
	switch(queuemsg.type)
	{
		case 1: 		
		    bmsg =  deal_recive_data(queuemsg);
		break;
		  
		case 2:
            bmsg =  deal_touch_data(queuemsg);
        break;		
		
		default:
		break;
	}
	return bmsg;
}


bmsg_t deal_recive_data(queuemsg_t queuemsg )//�������յ�������
{
    bmsg_t bmsg;
	
	if(queuemsg.msg.type)
	{
		switch(queuemsg.msg.subtype)
		{	
			//ͬ������
			case 0:
				 qingrd.enable = HOME;
                 wchar_t *pbegin =L"begin";	
                 Lcd_Show_FreeType(lcd,pbegin,28,0xffffff,0,0,600,300);
                 bmsg.enable = 0;    	  
			break;
			//��ͬ������
			case 1:
				qingrd.next = 1;
			break;
			
			//�յ�����
			case 2: 
			{
				qingrd.next = 1;
				bmsg.msg.type = 0 ;
				bmsg.msg.subtype = 0;
				bmsg.enable = 0;
                queuemsg.point.x=0;
                queuemsg.point.y=0;
			}			    
			break;
			//�յ�����
			case 3:       
			{
				  if(NET == qingrd.enable)
				  {
					  int    x ,y ;
					  x = queuemsg.msg.values[0];
					  y = queuemsg.msg.values[1];
                      color2=queuemsg.msg.values[2];
                      qingrd.qincolor=color2;
					  qingrd.touchgrd[y][x] = queuemsg.msg.values[2];
					  show_qinq();
					  qingrd.enable = HOME;
					  bmsg.enable = 0;	
				  }
				  
			}
			break;
			
			default:
				
			break;	
		}			
	}
	return bmsg;
}


bmsg_t deal_touch_data(queuemsg_t queuemsg )
{
    bmsg_t bmsg={0};

	int x  = 0, y = 0;
	x = queuemsg.point.x/40;
	y = queuemsg.point.y/40;
	
    bmsg.msg.type = 0 ;
    bmsg.msg.subtype = 0;
	printf("x=%d,y=%d\n",queuemsg.point.x,queuemsg.point.y);
	printf("T \n"); 
	if((x <12)&&(y < 12)&&(HOME == qingrd.enable))  //������س�������
	{
		printf("s \n"); 
        qingrd.qincolor = color1;
		qingrd.touchgrd[y][x] = qingrd.qincolor ; //��ʾ��ų�����                      
		qingrd.enable = NET;
		
		bmsg.msg.type = 20 ;
		bmsg.msg.subtype = 3;
		
		bmsg.msg.values[0] = x;
		bmsg.msg.values[1] = y;
		bmsg.msg.values[2] = qingrd.qincolor;
		
		bmsg.enable = 1;	
        return bmsg;			
	}
	else
	{
		printf("T1 \n"); 
		//--------ѡ���ɫ
		if(( queuemsg.point.x < 600)&&( queuemsg.point.x > 520)) // (540 ,580 )
		{
			if(( queuemsg.point.y < 140)&&( queuemsg.point.y > 60))//(80 , 120)
			{
                printf("bai \n");
				color1 = WHITE;
			}
		}		
		//---------ѡ���ɫ
		if(( queuemsg.point.x > 680)&&( queuemsg.point.x < 760)) // (700 ,740 )
		{
			
			if(( queuemsg.point.y < 140)&&( queuemsg.point.y > 60))//(80 , 120)
			{
                printf("hei \n");
				color1 = BLACK;
			}
		}
        
        //---------	����	
		if(( 720 < queuemsg.point.x)&&( point.x < 800)) // 
		{
			if(( 420 < queuemsg.point.y )&&( queuemsg.point.y < 480))//
			{
				qingrd.next = 1;
				bmsg.msg.type = 20 ;
				bmsg.msg.subtype = 2;
				bmsg.enable = 1;
                queuemsg.point.x=0;
                queuemsg.point.y=0;
                return bmsg;
                			
			}
		}
		//-----------------�������� 
		if(( 480 < queuemsg.point.x )&&( queuemsg.point.x < 550)) // (700 ,740 )
		{
			if((420 < queuemsg.point.y )&&( queuemsg.point.y < 480))//(80 , 120)
			{
				qingrd.enable = HOME;
                printf("request !\n"); 
				
				bmsg.msg.type = 20 ;
				bmsg.msg.subtype = 0;
				bmsg.enable = 1;
                queuemsg.point.x=0;
                queuemsg.point.y=0;
                return bmsg;
                
			}
		} 

		/*//---------------ͬ������ 
		if(( 0 < queuemsg.point.x )&&( queuemsg.point.x < 80)) // (700 ,740 )
		{
			if((420 < queuemsg.point.y )&&( queuemsg.point.y < 480))//(80 , 120)
			{
				 qingrd.enable = NET;
			}
		} 

		//---------------��ͬ�� 
		if(( 0 < queuemsg.point.x )&&( queuemsg.point.x < 80)) // (700 ,740 )
		{
			if((420 < queuemsg.point.y )&&( queuemsg.point.y < 480))//(80 , 120)
			{
				qingrd.next = 1;
			}
		} */		
        		
	}
	
	return bmsg;
}

