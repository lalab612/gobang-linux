#ifndef _READBMP_H_
#define _READBMP_H_
extern int read_bmp(char *filename ,int offset_x , int offset_y , char show_type);
extern int show_qinq();
extern int show_judge();
extern void init_show();
#endif 